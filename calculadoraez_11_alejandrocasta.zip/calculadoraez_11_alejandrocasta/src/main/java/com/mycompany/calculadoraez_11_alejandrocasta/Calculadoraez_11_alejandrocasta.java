/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadoraez_11_alejandrocasta;

/**
 *
 * @author LABORATORIO
 */
public class Calculadoraez_11_alejandrocasta {

    public static void main(String[] args) {
        jrfmcalc v1=new jrfmcalc();
        v1.setVisible(true);
    }
}
